import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { PageShell } from "@/components/PageShell";
import { ArrowRight } from "lucide-react";

type Pkg = {
  tag: string;
  name: string;
  sub: string;
  features: string[];
  featured?: boolean;
  accent: string;
};

const content: Pkg[] = [
  { tag: "Entry", name: "Essential Presence", sub: "1 visit monthly", accent: "bg-yellow",
    features: ["4 reels", "12 edited images", "On-site production visit"] },
  { tag: "Most popular", name: "Growth Visibility", sub: "2 visits monthly", accent: "bg-teal", featured: true,
    features: ["8 reels", "25 edited images", "2 on-site production visits", "Content calendar included"] },
  { tag: "Signature", name: "Signature Destination", sub: "3 visits monthly", accent: "bg-pink",
    features: ["12 reels", "40 edited images", "Experience documentation", "Full brand content system"] },
];

const campaign: Pkg[] = [
  { tag: "Starter", name: "Starter Campaign", sub: "Launch-ready", accent: "bg-blue",
    features: ["1 advertisement", "2 reels", "2 posters"] },
  { tag: "Most popular", name: "Growth Campaign", sub: "Scale-ready", accent: "bg-yellow", featured: true,
    features: ["1 advertisement", "4 reels", "4 posters"] },
  { tag: "Signature", name: "Signature Campaign", sub: "Full production", accent: "bg-pink",
    features: ["1 cinematic advertisement", "6 reels + 6 posters", "WhatsApp posters", "Website banners"] },
];

const systems: Pkg[] = [
  { tag: "Foundation", name: "Brand Foundation", sub: "One-time build", accent: "bg-yellow",
    features: ["Brand positioning", "Typography & color system", "Logo refinement", "Presentation templates"] },
  { tag: "Systems", name: "Marketing Systems", sub: "Strategy + structure", accent: "bg-teal", featured: true,
    features: ["Offer clarity", "Campaign messaging", "Posting structure", "Landing page direction"] },
  { tag: "Operations", name: "AI Operations", sub: "Automation build", accent: "bg-lavender",
    features: ["CRM setup", "Lead tracking", "Task automation", "Calendar + dashboard setup"] },
  { tag: "Reputation", name: "Reputation System", sub: "Trust workflow", accent: "bg-pink",
    features: ["Google review workflow", "TripAdvisor workflow", "Response templates", "Reminder timing structure"] },
];

function Card({ p }: { p: Pkg }) {
  return (
    <div className={`brutal-card p-7 ${p.featured ? "bg-navy text-canvas" : ""}`}>
      <div className="flex items-center justify-between">
        <span className={`inline-block rounded-md border-2 border-navy px-2.5 py-1 font-mono text-[0.55rem] uppercase tracking-[0.14em] ${p.featured ? "bg-yellow text-navy border-yellow" : `${p.accent} text-navy`}`}>
          {p.tag}
        </span>
      </div>
      <h3 className={`mt-5 font-display text-2xl font-extrabold leading-tight ${p.featured ? "text-canvas" : "text-navy"}`}>{p.name}</h3>
      <div className={`mt-1 font-mono text-[0.6rem] uppercase tracking-[0.14em] ${p.featured ? "text-canvas/60" : "text-ink-muted"}`}>{p.sub}</div>
      <ul className="mt-6 space-y-3">
        {p.features.map((f) => (
          <li key={f} className="flex items-start gap-3 text-sm">
            <span className={`mt-1.5 inline-block h-2 w-2 flex-shrink-0 rounded-full ${p.featured ? "bg-yellow" : "bg-navy"}`} />
            <span className={p.featured ? "text-canvas/85" : "text-ink"}>{f}</span>
          </li>
        ))}
      </ul>
      <Link to="/discovery" className={`mt-7 inline-flex items-center gap-2 font-mono text-[0.62rem] uppercase tracking-[0.12em] ${p.featured ? "text-yellow" : "text-navy"}`}>
        Get started <ArrowRight size={12} />
      </Link>
    </div>
  );
}

function Group({ label, items }: { label: string; items: Pkg[] }) {
  return (
    <div className="mt-16">
      <div className="eyebrow mb-3">{label}</div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => <Card key={p.name} p={p} />)}
      </div>
    </div>
  );
}

export default function PackagesPage() {
  return (
    <PageShell>
      <Helmet>
        <title>Packages — TODO Growth</title>
        <meta name="description" content="Content, campaign, reputation, brand foundation, marketing systems, and AI operations packages — built for your stage of growth." />
        <meta property="og:title" content="Packages — TODO Growth" />
        <meta property="og:description" content="Built for your stage of growth." />
      </Helmet>

      <section className="px-6 pb-24 pt-16 md:px-14">
        <div className="mx-auto max-w-6xl">
          <div className="eyebrow mb-4">02 — Packages</div>
          <h1 className="section-title">Built for your<br /><em>stage of growth.</em></h1>
          <p className="mt-6 max-w-2xl text-[0.95rem] leading-[1.8] text-ink-muted">
            Start with what you need today. Scale into the full system as your business grows. Every engagement begins with a free Discovery Session.
          </p>

          <Group label="Content packages" items={content} />
          <Group label="Campaign packages" items={campaign} />
          <Group label="Systems & foundation" items={systems} />
        </div>
      </section>
    </PageShell>
  );
}