import { Helmet } from "react-helmet-async";
import { PageShell } from "@/components/PageShell";
import { ArrowRight } from "lucide-react";
import { useState } from "react";

const items = [
  { color: "bg-yellow", title: "Brand clarity review", desc: "We assess how your brand reads in market and where it loses trust or attention." },
  { color: "bg-teal", title: "Marketing gap identification", desc: "We find where your content, messaging, and distribution are losing potential clients." },
  { color: "bg-orange", title: "Workflow bottleneck detection", desc: "We surface operational drag — tasks that slow your team and can be automated." },
  { color: "bg-pink", title: "Growth opportunity mapping", desc: "A prioritized roadmap of where to focus first for the clearest, fastest results." },
];

export default function DiscoveryPage() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const form = e.currentTarget;
    const data = new FormData(form);

    try {
      await fetch("https://formspree.io/f/YOUR_FORM_ID", {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" },
      });
      setSubmitted(true);
    } catch {
      // fallback: open mailto
      const name = data.get("name") as string;
      const email = data.get("email") as string;
      const message = data.get("message") as string;
      window.location.href = `mailto:Richie@todo.rw?subject=Discovery Session — ${encodeURIComponent(name)}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`)}`;
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell>
      <Helmet>
        <title>Discovery Session — TODO Growth</title>
        <meta name="description" content="A focused, free first session to map brand gaps, marketing blind spots, workflow bottlenecks, and growth opportunities." />
        <meta property="og:title" content="Discovery Session — TODO Growth" />
        <meta property="og:description" content="Where every engagement starts." />
      </Helmet>

      <section className="grid gap-12 px-6 pb-24 pt-16 md:px-14 lg:grid-cols-[1.3fr_1fr]">
        {/* Left column */}
        <div className="mx-auto w-full max-w-2xl lg:mx-0">
          <div className="eyebrow mb-4">05 — Discovery Session</div>
          <h1 className="section-title">Where every<br /><em>engagement starts.</em></h1>
          <p className="mt-6 max-w-xl text-[0.95rem] leading-[1.8] text-ink-muted">
            A focused session designed to map your brand gaps, marketing blind spots, workflow bottlenecks, and the fastest path to visible growth.
          </p>

          <div className="mt-12 space-y-5">
            {items.map((i) => (
              <div key={i.title} className="flex gap-5">
                <div className={`mt-1 h-12 w-1.5 flex-shrink-0 rounded ${i.color}`} />
                <div>
                  <div className="font-display text-lg font-bold text-navy">{i.title}</div>
                  <p className="mt-1 text-sm leading-relaxed text-ink-muted">{i.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column — booking form */}
        <aside className="brutal-card h-fit bg-navy p-8 text-canvas lg:sticky lg:top-24">
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.18em] text-yellow">Book your session</div>
          <h2 className="mt-3 font-display text-3xl font-extrabold leading-tight">
            Start the<br /><em className="not-italic text-teal">conversation.</em>
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-canvas/70">
            First sessions are focused and free. We only proceed together if it's the right fit.
          </p>

          {submitted ? (
            <div className="mt-8 rounded-lg border border-teal/40 bg-teal/10 px-5 py-6 text-center">
              <div className="font-display text-lg font-bold text-teal">You're in.</div>
              <p className="mt-2 text-sm text-canvas/70">We'll be in touch within one business day to confirm your session.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-7 space-y-4">
              {/* Name */}
              <div>
                <label htmlFor="name" className="mb-1.5 block font-mono text-[0.6rem] uppercase tracking-widest text-canvas/50">
                  Your name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  placeholder="Jane Doe"
                  className="w-full rounded-lg border border-canvas/20 bg-canvas/10 px-4 py-2.5 text-sm text-canvas placeholder:text-canvas/30 focus:border-teal focus:outline-none focus:ring-1 focus:ring-teal"
                />
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="mb-1.5 block font-mono text-[0.6rem] uppercase tracking-widest text-canvas/50">
                  Email address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  placeholder="jane@yourcompany.com"
                  className="w-full rounded-lg border border-canvas/20 bg-canvas/10 px-4 py-2.5 text-sm text-canvas placeholder:text-canvas/30 focus:border-teal focus:outline-none focus:ring-1 focus:ring-teal"
                />
              </div>

              {/* Business */}
              <div>
                <label htmlFor="business" className="mb-1.5 block font-mono text-[0.6rem] uppercase tracking-widest text-canvas/50">
                  Your business <span className="text-canvas/30">(optional)</span>
                </label>
                <input
                  id="business"
                  name="business"
                  type="text"
                  placeholder="Company or project name"
                  className="w-full rounded-lg border border-canvas/20 bg-canvas/10 px-4 py-2.5 text-sm text-canvas placeholder:text-canvas/30 focus:border-teal focus:outline-none focus:ring-1 focus:ring-teal"
                />
              </div>

              {/* Focus area */}
              <div>
                <label htmlFor="focus" className="mb-1.5 block font-mono text-[0.6rem] uppercase tracking-widest text-canvas/50">
                  Biggest challenge right now
                </label>
                <select
                  id="focus"
                  name="focus"
                  required
                  defaultValue=""
                  className="w-full rounded-lg border border-canvas/20 bg-navy px-4 py-2.5 text-sm text-canvas focus:border-teal focus:outline-none focus:ring-1 focus:ring-teal"
                >
                  <option value="" disabled className="text-canvas/30">Select one…</option>
                  <option value="brand">Brand clarity &amp; positioning</option>
                  <option value="marketing">Marketing &amp; content gaps</option>
                  <option value="workflow">Workflow &amp; operations</option>
                  <option value="growth">Growth strategy &amp; roadmap</option>
                  <option value="unsure">Not sure yet</option>
                </select>
              </div>

              {/* Message */}
              <div>
                <label htmlFor="message" className="mb-1.5 block font-mono text-[0.6rem] uppercase tracking-widest text-canvas/50">
                  Anything else <span className="text-canvas/30">(optional)</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={3}
                  placeholder="Give us a bit of context…"
                  className="w-full resize-none rounded-lg border border-canvas/20 bg-canvas/10 px-4 py-2.5 text-sm text-canvas placeholder:text-canvas/30 focus:border-teal focus:outline-none focus:ring-1 focus:ring-teal"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="mt-1 inline-flex w-full items-center justify-center gap-2 rounded-lg border-[2.5px] border-yellow bg-yellow px-5 py-3 font-display text-sm font-bold uppercase tracking-wide text-navy transition hover:bg-orange disabled:opacity-60"
              >
                {loading ? "Sending…" : <><span>Book Discovery Session</span><ArrowRight size={14} /></>}
              </button>

              <p className="text-center font-mono text-[0.55rem] uppercase tracking-wider text-canvas/30">
                Free · No commitment · Kigali, Rwanda
              </p>
            </form>
          )}
        </aside>
      </section>
    </PageShell>
  );
}