import { Helmet } from "react-helmet-async";
import { PageShell } from "@/components/PageShell";

const steps = [
  { num: "01", name: "Audit", color: "bg-yellow", desc: "We assess your current brand, visibility gaps, and workflow friction before recommending anything." },
  { num: "02", name: "Strategy", color: "bg-teal", desc: "A clear plan: which systems to build, in what order, and what each one is designed to achieve." },
  { num: "03", name: "Build", color: "bg-pink", desc: "We execute — content production, brand systems, automation workflows — with precision and speed." },
  { num: "04", name: "Launch", color: "bg-blue", desc: "Everything goes live, coordinated and on-brand, with campaign and distribution support from us." },
  { num: "05", name: "Support", color: "bg-lavender", desc: "Ongoing monthly production, system maintenance, and performance iteration as your brand grows." },
];

export default function ApproachPage() {
  return (
    <PageShell>
      <Helmet>
        <title>Our Approach — TODO Growth</title>
        <meta name="description" content="Audit, Strategy, Build, Launch, Support — the five-step process behind every TODO engagement." />
        <meta property="og:title" content="Our Approach — TODO Growth" />
        <meta property="og:description" content="How we work: audit, strategy, build, launch, support." />
      </Helmet>

      <section className="px-6 pb-24 pt-16 md:px-14">
        <div className="mx-auto max-w-5xl">
          <div className="eyebrow mb-4">04 — Our approach</div>
          <h1 className="section-title">How we<br /><em>work.</em></h1>

          <div className="mt-16 space-y-6">
            {steps.map((s) => (
              <div key={s.num} className="brutal-card grid gap-6 p-7 md:grid-cols-[140px_1fr] md:items-center">
                <div className={`inline-flex h-20 w-20 items-center justify-center rounded-2xl border-[2.5px] border-navy ${s.color}`}>
                  <span className="font-display text-3xl font-extrabold text-navy">{s.num}</span>
                </div>
                <div>
                  <h3 className="font-display text-2xl font-bold text-navy">{s.name}</h3>
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-muted">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}