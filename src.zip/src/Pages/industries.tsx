import { Helmet } from "react-helmet-async";
import { PageShell } from "@/components/PageShell";
import { Hotel, UtensilsCrossed, Building2, Plane, ShoppingBag, HeartPulse } from "lucide-react";

const items = [
  { icon: Hotel, name: "Hospitality", color: "bg-yellow", desc: "Hotels, lodges, and resorts that need consistent visual content and pristine review systems." },
  { icon: UtensilsCrossed, name: "Restaurants & Cafés", color: "bg-pink", desc: "Menu storytelling, dish reels, and reservation workflow automation." },
  { icon: Building2, name: "Real Estate", color: "bg-teal", desc: "Listing photography, cinematic walk-throughs, and lead-tracking CRM setup." },
  { icon: Plane, name: "Tourism & Experiences", color: "bg-blue", desc: "Experience documentation, destination marketing, and TripAdvisor reputation workflows." },
  { icon: ShoppingBag, name: "Retail & E-commerce", color: "bg-orange", desc: "Product content systems, campaign creative, and structured posting calendars." },
  { icon: HeartPulse, name: "Clinics & Services", color: "bg-lavender", desc: "Trust-first branding, calendar coordination, and review reminder automation." },
];

export default function IndustriesPage() {
  return (
    <PageShell>
      <Helmet>
        <title>Industries — TODO Growth</title>
        <meta name="description" content="Brand, content, and AI workflows for hospitality, restaurants, real estate, tourism, retail, and clinics across East Africa." />
        <meta property="og:title" content="Industries — TODO Growth" />
        <meta property="og:description" content="Built for the businesses shaping East Africa." />
      </Helmet>

      <section className="px-6 pb-24 pt-16 md:px-14">
        <div className="mx-auto max-w-6xl">
          <div className="eyebrow mb-4">03 — Industries</div>
          <h1 className="section-title">Built for the businesses<br /><em>shaping East Africa.</em></h1>
          <p className="mt-6 max-w-2xl text-[0.95rem] leading-[1.8] text-ink-muted">
            Each industry has its own visibility patterns, trust signals, and workflow bottlenecks. We tune the system to yours.
          </p>

          <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {items.map((it) => (
              <div key={it.name} className="brutal-card p-7">
                <div className={`mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl border-[2.5px] border-navy ${it.color}`}>
                  <it.icon size={20} className="text-navy" />
                </div>
                <h3 className="font-display text-xl font-bold text-navy">{it.name}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-muted">{it.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}