import { Helmet } from "react-helmet-async";
import { PageShell } from "@/components/PageShell";
import { Mail, MapPin, MessageCircle } from "lucide-react";

export default function ContactPage() {
  return (
    <PageShell>
      <Helmet>
        <title>Contact — TODO Growth</title>
        <meta name="description" content="Reach the TODO Growth studio in Kigali, Rwanda. Email hello@todo.rw or message us on WhatsApp." />
        <meta property="og:title" content="Contact — TODO Growth" />
        <meta property="og:description" content="Kigali · hello@todo.rw · WhatsApp" />
      </Helmet>

      <section className="px-6 pb-24 pt-16 md:px-14">
        <div className="mx-auto max-w-5xl">
          <div className="eyebrow mb-4">06 — Contact</div>
          <h1 className="section-title">Let's<br /><em>talk.</em></h1>
          <p className="mt-6 max-w-xl text-[0.95rem] leading-[1.8] text-ink-muted">
            Tell us about your brand, your bottleneck, or the campaign you're trying to ship. We'll respond within one working day.
          </p>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            <a href="mailto:hello@todo.rw" className="brutal-card flex flex-col gap-4 p-7">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl border-[2.5px] border-navy bg-yellow"><Mail size={20} className="text-navy" /></span>
              <div>
                <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">Email</div>
                <div className="mt-1 font-display text-lg font-bold text-navy">hello@todo.rw</div>
              </div>
            </a>
            <a href="https://wa.me/250000000000" className="brutal-card flex flex-col gap-4 p-7">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl border-[2.5px] border-navy bg-teal"><MessageCircle size={20} className="text-navy" /></span>
              <div>
                <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">WhatsApp</div>
                <div className="mt-1 font-display text-lg font-bold text-navy">+250 XXX XXX XXX</div>
              </div>
            </a>
            <div className="brutal-card flex flex-col gap-4 p-7">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl border-[2.5px] border-navy bg-pink"><MapPin size={20} className="text-navy" /></span>
              <div>
                <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">Studio</div>
                <div className="mt-1 font-display text-lg font-bold text-navy">Kigali, Rwanda</div>
              </div>
            </div>
          </div>

          <form className="brutal-card mt-12 space-y-5 p-8" onSubmit={(e) => { e.preventDefault(); window.location.href = "mailto:hello@todo.rw"; }}>
            <div className="grid gap-5 md:grid-cols-2">
              <label className="block">
                <span className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">Name</span>
                <input required className="mt-2 w-full rounded-lg border-2 border-navy bg-canvas px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal" />
              </label>
              <label className="block">
                <span className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">Email</span>
                <input required type="email" className="mt-2 w-full rounded-lg border-2 border-navy bg-canvas px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal" />
              </label>
            </div>
            <label className="block">
              <span className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-ink-muted">Message</span>
              <textarea required rows={5} className="mt-2 w-full rounded-lg border-2 border-navy bg-canvas px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal" />
            </label>
            <button type="submit" className="btn-primary">Send message</button>
          </form>
        </div>
      </section>
    </PageShell>
  );
}