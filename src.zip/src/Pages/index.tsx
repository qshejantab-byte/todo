import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { PageShell } from "@/components/PageShell";
import { ArrowRight, Sparkles, Megaphone, Camera, Star, Bot } from "lucide-react";

type CoreItem = {
  icon: React.ElementType;
  label: string;
  color: string;
  hover: string;
};

const cores: CoreItem[] = [
  { icon: Sparkles, label: "Branding", color: "bg-yellow", hover: "var(--color-yellow)" },
  { icon: Megaphone, label: "Marketing Systems", color: "bg-teal", hover: "var(--color-teal)" },
  { icon: Camera, label: "Content Production", color: "bg-pink", hover: "var(--color-pink)" },
  { icon: Star, label: "Reputation Management", color: "bg-blue", hover: "var(--color-blue)" },
  { icon: Bot, label: "AI Automation", color: "bg-lavender", hover: "var(--color-lavender)" },
];
export default function HomePage() {
  return (
    <PageShell>
      <Helmet>
        <title>TODO Growth — Brand Better. Market Smarter. Operate with AI.</title>
        <meta name="description" content="TODO helps businesses improve presentation, visibility, customer trust, and internal coordination through branding, content systems, reputation management, and automation workflows." />
        <meta property="og:title" content="TODO Growth — Brand Better. Market Smarter. Operate with AI." />
        <meta property="og:description" content="Visual infrastructure for ambitious businesses in East Africa." />
      </Helmet>

      {/* HERO */}
      <section className="relative grid min-h-[calc(100vh-78px)] grid-cols-1 overflow-hidden lg:grid-cols-2">
        <div className="grid-bg absolute inset-0 pointer-events-none" />
        <div className="relative z-10 flex flex-col justify-center px-6 py-16 md:px-14">
          <div className="eyebrow mb-6 flex items-center gap-3">
            <span className="block h-[2px] w-6 rounded bg-teal" />
            Kigali, Rwanda — Visual Infrastructure
          </div>
         <h1 className="mb-6 font-display text-[clamp(2.8rem,6vw,5.6rem)] font-extrabold leading-[0.98] tracking-[-0.04em] text-navy">
  <span className="text-yellow [-webkit-text-stroke:1.5px_var(--navy)]">Brand</span> better.<br />
  Market <span className="text-teal italic font-medium">smarter.</span><br />
  Operate with <span className="text-pink">AI.</span>
</h1>
          <p className="mb-10 max-w-md text-[0.95rem] leading-[1.85] text-ink-muted">
            TODO helps businesses improve presentation, visibility, customer trust, and internal coordination through branding, content systems, reputation management, and automation workflows.
          </p>
          <div className="flex flex-wrap items-center gap-5">
            <Link to="/packages" className="btn-primary">
              View Packages <ArrowRight size={16} />
            </Link>
            <Link to="/discovery" className="btn-ghost">
              Book Discovery Session →
            </Link>
          </div>
        </div>

      <div className="relative flex items-center justify-center bg-navy p-12">
  <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.07) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />
  <div className="relative h-[420px] w-full max-w-[420px]">

    {/* Card 1 — Content Production */}
    <div className="absolute left-0 top-4 w-[260px] -rotate-[4deg] rounded-2xl border-[2.5px] border-navy bg-yellow p-7 transition-transform duration-300 ease-out hover:-translate-y-2 hover:rotate-[-6deg] hover:scale-[1.03]">
      <div className="font-mono text-[0.55rem] uppercase tracking-[0.16em] text-navy/55">Content Production</div>
      <div className="mt-2 font-display text-3xl font-extrabold leading-tight tracking-tight text-navy">Visual<br />Infrastructure</div>
      <div className="mt-3 font-display text-5xl font-extrabold tracking-tight text-navy">40+</div>
      <div className="font-mono text-[0.55rem] uppercase tracking-[0.14em] text-navy/45">assets / month</div>
    </div>

    {/* Card 2 — Brand Foundation */}
    <div className="absolute left-40 top-40 w-[250px] rotate-[2.5deg] rounded-2xl border-[2.5px] border-navy bg-canvas p-6 shadow-[4px_4px_0_var(--navy)] transition-transform duration-300 ease-out hover:-translate-y-2 hover:rotate-[4deg] hover:scale-[1.03]">
      <div className="font-mono text-[0.55rem] uppercase tracking-[0.16em] text-ink-muted">Brand Foundation</div>
      <div className="mt-2 font-display text-2xl font-bold leading-tight tracking-tight text-navy">Complete<br />Identity System</div>
      <div className="mt-3 h-3 w-3 rounded-full border-2 border-navy bg-pink" />
    </div>

    {/* Card 3 — AI Operations */}
    <div className="absolute  top-66 w-[220px] -rotate-[2deg] rounded-2xl border-[2.5px] border-navy bg-teal p-6 transition-transform duration-300 ease-out hover:-translate-y-2 hover:rotate-[-4deg] hover:scale-[1.03]">
      <div className="font-mono text-[0.55rem] uppercase tracking-[0.16em] text-navy/55">AI Operations</div>
      <div className="mt-2 font-display text-3xl font-extrabold leading-tight tracking-tight text-navy">Growth<br />Engine</div>
    </div>

  </div>
</div>
      </section>

      {/* CORE AREAS */}
      <section className="border-t border-border px-6 py-24 md:px-14">
        <div className="mx-auto max-w-6xl">
          <div className="eyebrow mb-4">01 — Core Areas</div>
          <h2 className="section-title mb-12">Five systems.<br /><em>One growth engine.</em></h2>
       <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
  {cores.map((c) => (
    <div
      key={c.label}
      className="brutal-card p-6 transition-colors duration-200"
      style={{ "--card-hover": c.hover } as React.CSSProperties}
      onMouseEnter={e => (e.currentTarget as HTMLElement).style.backgroundColor = c.hover}
      onMouseLeave={e => (e.currentTarget as HTMLElement).style.backgroundColor = ""}
    >
      <div className={`mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl border-[2.5px] border-navy ${c.color}`}>
        <c.icon size={20} className="text-navy" />
      </div>
      <div className="font-display text-lg font-bold text-navy">{c.label}</div>
    </div>
  ))}
</div>
        </div>
      </section>

      {/* TEASER CTA */}
      <section className="border-t border-border bg-canvas-alt px-6 py-24 md:px-14">
        <div className="mx-auto grid max-w-6xl items-center gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <div className="eyebrow mb-4">Discovery Session</div>
            <h2 className="section-title">Where every<br /><em>engagement starts.</em></h2>
            <p className="mt-6 max-w-xl text-[0.95rem] leading-[1.8] text-ink-muted">
              A focused, free first session designed to map your brand gaps, marketing blind spots, workflow bottlenecks, and the fastest path to visible growth.
            </p>
          </div>
          <div className="brutal-card bg-navy p-8 text-canvas">
            <div className="font-mono text-[0.6rem] uppercase tracking-[0.18em] text-yellow">Book your session</div>
            <h3 className="mt-3 font-display text-3xl font-extrabold leading-tight">Start the<br /><em className="not-italic text-teal">conversation.</em></h3>
            <Link to="/discovery" className="mt-6 inline-flex items-center gap-2 rounded-lg border-[2.5px] border-yellow bg-yellow px-5 py-3 font-display text-sm font-bold uppercase tracking-wide text-navy transition hover:bg-orange">
              Book now <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}