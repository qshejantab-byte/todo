import { Link } from "react-router-dom";
import LOGO from "../assets/LOGO.png";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-navy px-6 py-12 text-canvas md:px-14">
      <div className="mx-auto flex max-w-6xl flex-col justify-between gap-8 md:flex-row md:items-end">
        <div>
          <div className="flex items-center gap-3">
              <img src={LOGO} className="h-10 w-10" alt="Logo" />
            {/* <span className="font-display text-xl font-extrabold tracking-tight">
              Growth 
            </span> */}
          </div>
          <p className="mt-4 max-w-md font-mono text-[0.65rem] uppercase tracking-[0.14em] text-canvas/55">
            Visual infrastructure for East Africa · Kigali, Rwanda · 2026
          </p>
        </div>
        <div className="flex flex-wrap gap-6 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-canvas/70">
          <Link to="/packages" className="hover:text-yellow">Packages</Link>
          <Link to="/approach" className="hover:text-yellow">Approach</Link>
          <Link to="/industries" className="hover:text-yellow">Industries</Link>
          <a href="mailto:hello@todo.rw" className="hover:text-yellow">hello@todo.rw</a>
        </div>
      </div>
    </footer>
  );
}
