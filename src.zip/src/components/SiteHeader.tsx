import { Link } from "react-router-dom";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import LOGO from "../assets/LOGO.png";

const links = [
  { to: "/", label: "Home" },
  { to: "/packages", label: "Packages" },
  { to: "/industries", label: "Industries" },
  { to: "/approach", label: "Our Approach" },
  { to: "/discovery", label: "Discovery" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <nav className="fixed inset-x-0 top-0 z-50 flex items-center justify-between border-b border-border bg-canvas/90 px-6 py-4 backdrop-blur-md md:px-14">
      <Link to="/" className="flex items-center gap-2.5">
        <img src={LOGO} className="h-10 w-10" alt="Logo" />
        {/* <span className="font-display text-xl font-extrabold leading-none tracking-tight text-navy">
          GROWTH
        </span> */}
      </Link>

      <ul className="hidden items-center gap-8 lg:flex">
        {links.slice(0, -1).map((l) => (
          <li key={l.to}>
            <Link
              to={l.to}
              className="font-mono text-[0.62rem] uppercase tracking-[0.09em] text-ink-muted transition-colors hover:text-navy"
              // activeProps={{ className: "!text-navy" }}
              // activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          </li>
        ))}
        <li>
          <Link
            to="/discovery"
            className="rounded-lg border-2 border-navy bg-yellow px-5 py-2 font-mono text-[0.62rem] font-semibold uppercase tracking-[0.09em] text-navy transition-all hover:-translate-y-px hover:bg-orange"
          >
            Book Now
          </Link>
        </li>
      </ul>

      <button
        aria-label="Menu"
        onClick={() => setOpen((s) => !s)}
        className="rounded-md border-2 border-navy p-2 text-navy lg:hidden"
      >
        {open ? <X size={18} /> : <Menu size={18} />}
      </button>

      {open && (
        <div className="absolute inset-x-0 top-full border-b border-border bg-canvas px-6 py-4 lg:hidden">
          <ul className="flex flex-col gap-4">
            {links.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  onClick={() => setOpen(false)}
                  className="font-mono text-xs uppercase tracking-[0.1em] text-navy"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </nav>
  );
}
